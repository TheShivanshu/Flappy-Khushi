const game = document.getElementById("game");
const bird = document.getElementById("bird");
const scoreDisplay = document.getElementById("scoreDisplay");
const startMenu = document.getElementById("startMenu");
const startBtn = document.getElementById("startBtn");
const endScreen = document.getElementById("endScreen");
const finalScore = document.getElementById("finalScore");
const restartBtn = document.getElementById("restartBtn");
const pipesContainer = document.getElementById("pipesContainer");

let birdY = 250;
let velocity = 0;
let gravity = 0.35;
let lift = -6.9;
let score = 0;
let highScore = localStorage.getItem("highScore") || 0;
let pipes = [];
let pipeWidth = 60;
let pipeGap = 160;
let pipeSpeed = 2.3;
let gameRunning = false;
let difficultyInterval;

let hasShield = false;
let shieldItem = null;

/* BONUS ITEMS */
let coinItem = null;
let starItem = null;

/* SOUNDS */
const flapS = new Audio("sounds/flap.mp3");
const hitS = new Audio("sounds/hit.mp3");
const dieS = new Audio("sounds/die.mp3");
const pointS = new Audio("sounds/point.mp3");
const coinS = new Audio("sounds/coin.mp3");
const starS = new Audio("sounds/star.mp3");
const shieldS = new Audio("sounds/shield.mp3");
const shieldBreakS = new Audio("sounds/shield-break.mp3");

/* START & RESTART */
startBtn.addEventListener("click", () => { startMenu.style.display = "none"; startGame(); });
restartBtn.addEventListener("click", () => { endScreen.style.display = "none"; startGame(); });

/* CONTROLS */
document.addEventListener("keydown", e => {
    if(gameRunning && (e.code === "Space" || e.code === "ArrowUp")){
        velocity = lift;
        flapS.play();
    }
});

/* START GAME */
function startGame(){
    resetGame();
    gameRunning = true;
    difficultyInterval = setInterval(() => { pipeSpeed += 0.05; }, 6000);
    requestAnimationFrame(draw);
}

/* RESET GAME */
function resetGame(){
    birdY = 250;
    velocity = 0;
    score = 0;
    pipeSpeed = 2.3;
    scoreDisplay.innerText = score;

    hasShield = false;
    bird.classList.remove("shieldActive");

    pipes.forEach(p => { p.top.remove(); p.bottom.remove(); });
    pipes = [];

    if(coinItem){ coinItem.remove(); coinItem = null; }
    if(starItem){ starItem.remove(); starItem = null; }
    if(shieldItem){ shieldItem.remove(); shieldItem = null; }

    pipes.push(createPipe(game.offsetWidth));
}

/* CREATE PIPE */
function createPipe(x){
    let height = Math.random() * (game.offsetHeight - pipeGap - 150) + 60;

    let top = document.createElement("div");
    top.classList.add("pipe","top");
    top.style.height = height + "px";
    top.style.left = x + "px";

    let bottom = document.createElement("div");
    bottom.classList.add("pipe","bottom");
    bottom.style.height = (game.offsetHeight - height - pipeGap) + "px";
    bottom.style.top = (height + pipeGap) + "px";
    bottom.style.left = x + "px";

    pipesContainer.appendChild(top);
    pipesContainer.appendChild(bottom);

    return { x, height, passed: false, spawned: false, top, bottom };
}

/* SPAWN BONUS ITEMS */
function spawnCoin(p){
    if(Math.random() < 0.3 && !coinItem){
        coinItem = document.createElement("div");
        coinItem.className = "coin";
        coinItem.style.left = (p.x + 80) + "px";
        coinItem.style.top = (p.height + pipeGap/2) + "px";
        game.appendChild(coinItem);
    }
}
function spawnStar(p){
    if(Math.random() < 0.1 && !starItem){
        starItem = document.createElement("div");
        starItem.className = "star";
        starItem.style.left = (p.x + 80) + "px";
        starItem.style.top = (p.height + pipeGap/2 - 50) + "px";
        game.appendChild(starItem);
    }
}
function spawnShield(p){
    // 30% chance per pipe, faster than before
    if(Math.random() < 0.3 && !shieldItem){
        shieldItem = document.createElement("div");
        shieldItem.className = "shieldItem";
        shieldItem.style.left = (p.x + 80) + "px";
        shieldItem.style.top = (p.height + pipeGap/2 + 50) + "px";
        game.appendChild(shieldItem);
    }
}


/* COLLISION CHECK (USING OFFSETS) */
function hitOffsets(a,b){
    return !(
        a.x + a.width < b.x ||
        a.x > b.x + b.width ||
        a.y + a.height < b.y ||
        a.y > b.y + b.height
    );
}

/* MAIN GAME LOOP */
function draw(){
    if(!gameRunning) return;

    velocity += gravity;
    birdY += velocity;
    bird.style.top = birdY + "px";

    let rot = Math.max(Math.min(velocity*2, 25), -25);
    bird.style.transform = `rotate(${rot}deg)`;

    let birdRect = {
        x: bird.offsetLeft + 5,
        y: birdY + 5,
        width: bird.offsetWidth - 10,
        height: bird.offsetHeight - 10
    };

    for(let i = 0; i < pipes.length; i++){
        let p = pipes[i];
        p.x -= pipeSpeed;
        p.top.style.left = p.x + "px";
        p.bottom.style.left = p.x + "px";

        if(!p.spawned){
            spawnCoin(p);
            spawnStar(p);
            spawnShield(p);
            p.spawned = true;
        }

        if(!p.passed && p.x + pipeWidth < bird.offsetLeft){
            p.passed = true;
            score++;
            pointS.play();
            scoreDisplay.innerText = score;
        }

        let topRect = { x: p.x, y: 0, width: pipeWidth, height: p.height };
        let bottomRect = { x: p.x, y: p.height + pipeGap, width: pipeWidth, height: p.bottom.offsetHeight };

        if(hitOffsets(birdRect, topRect) || hitOffsets(birdRect, bottomRect)){
            if(hasShield){
                hasShield = false;
                bird.classList.remove("shieldActive");
                shieldBreakS.play();
            } else {
                hitS.play();
                setTimeout(()=>{ gameOver(); },150);
                return;
            }
        }

        if(p.x + pipeWidth < 0){
            p.top.remove();
            p.bottom.remove();
            pipes.splice(i,1);
            i--;
            pipes.push(createPipe(game.offsetWidth));
        }
    }

    /* BONUS ITEMS MOVEMENT */
    moveItem(coinItem, pipeSpeed*2.5, ()=>{
        coinS.play();
        score += 5;
        scoreDisplay.innerText = score;
        coinItem.remove();
        coinItem = null;
    });

    moveItem(starItem, pipeSpeed*2.8, ()=>{
        starS.play();
        score += 20;
        scoreDisplay.innerText = score;
        starItem.remove();
        starItem = null;
    });

    moveItem(shieldItem, pipeSpeed*2.3, ()=>{
        shieldS.play();
        hasShield = true;
        bird.classList.add("shieldActive");
        shieldItem.remove();
        shieldItem = null;
    });

    /* GROUND COLLISION */
    if(birdY + bird.offsetHeight > game.offsetHeight - 60){
        if(hasShield){
            hasShield = false;
            bird.classList.remove("shieldActive");
            shieldBreakS.play();
        } else {
            dieS.play();
            gameOver();
            return;
        }
    }

    if(birdY < 0) birdY = 0;

    requestAnimationFrame(draw);
}

/* MOVE ITEMS */
function moveItem(item, speed, onCollect){
    if(!item) return;

    let x = parseInt(item.style.left);
    x -= speed;
    item.style.left = x + "px";

    if(x < -50){
        item.remove();
        if(item === coinItem) coinItem = null;
        if(item === starItem) starItem = null;
        if(item === shieldItem) shieldItem = null;
        return;
    }

    let rect = {
        x: x,
        y: parseInt(item.style.top),
        width: item.offsetWidth,
        height: item.offsetHeight
    };

    let birdRect = {
        x: bird.offsetLeft + 5,
        y: birdY + 5,
        width: bird.offsetWidth - 10,
        height: bird.offsetHeight - 10
    };

    if(hitOffsets(birdRect, rect)){
        onCollect();
    }
}

/* GAME OVER */
function gameOver(){
    gameRunning = false;
    clearInterval(difficultyInterval);

    if(score > highScore){
        highScore = score;
        localStorage.setItem("highScore", highScore);
    }

    finalScore.innerText = `Score: ${score} | High Score: ${highScore}`;
    endScreen.style.display = "flex";
}
